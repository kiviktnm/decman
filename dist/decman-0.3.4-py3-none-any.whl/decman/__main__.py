import decman.app

decman.app.main()
